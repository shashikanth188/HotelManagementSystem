import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ReportService {
  // private month = 'http://localhost:5138/api/Report/monthly'; 

  private year = 'http://localhost:5138/api/Report/yearly';

  private range = 'http://localhost:5138/api/Report';

  constructor(private http: HttpClient) { }

getMonthlyRevenue(date: string): Observable<any> {
  const formattedDate = date.toString().slice(0, 7); // Format date as YYYY-MM
  const params = new HttpParams().set('date', formattedDate);
  return this.http.get<any>(`http://localhost:5138/api/Report/monthly/2`, { params });
}



  getYearlyRevenue(year: number): Observable<any> {
    const params = new HttpParams().set('year', year.toString());
    return this.http.get<any>(`${this.year}/yearly`, { params });
  }

  getRevenueByRange(fromDate: Date, toDate: Date): Observable<any> {
    const params = new HttpParams()
      .set('fromDate', fromDate.toString())
      .set('toDate', toDate.toString());
    return this.http.get<any>(`${this.range}/range`, { params });
  }
}
