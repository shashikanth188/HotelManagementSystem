import { Component, OnInit } from '@angular/core';
import { ReportService } from './report.service';  // Adjust the path as needed

@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.css']
})
export class ReportComponent implements OnInit {
  monthlyRevenue: number | null = null;
  yearlyRevenue: number | null = null;
  rangeRevenue: number | null = null;
  errorMessage: string | null = null;
  
  date: Date = new Date();
  year: number = new Date().getFullYear();
  fromDate: Date | null = null;
  toDate: Date | null = null;

  constructor(private reportService: ReportService) { }

  ngOnInit(): void {
    this.getMonthlyRevenue();
    this.getYearlyRevenue();
  }

  getMonthlyRevenue(): void {
    const formattedDate: string = this.date.toISOString().slice(0, 7); // Format date as YYYY-MM
    this.reportService.getMonthlyRevenue(formattedDate).subscribe(
        data => this.monthlyRevenue = data.revenue,
        error => this.errorMessage = 'Error fetching monthly revenue'
    );
}



  getYearlyRevenue(): void {
    this.reportService.getYearlyRevenue(this.year).subscribe(
      data => this.yearlyRevenue = data.revenue,
      error => this.errorMessage = 'Error fetching yearly revenue'
    );
  }

  getRevenueByRange(): void {
    if (this.fromDate && this.toDate) {
      this.reportService.getRevenueByRange(this.fromDate, this.toDate).subscribe(
        data => this.rangeRevenue = data.revenue,
        error => this.errorMessage = 'Error fetching revenue by range'
      );
    }
  }
}
