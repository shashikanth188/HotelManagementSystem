// import { HttpClient } from '@angular/common/http';
// import { Injectable } from '@angular/core';
// import { Observable } from 'rxjs';

// @Injectable({
//   providedIn: 'root'
// })
// export class LoginService {

//   private login = 'http://localhost:5138/api/Admin/login';
//   constructor(private http:HttpClient) { }

//   loginData(data:any):Observable<any>{
//     return this.http.post<any>(this.login,data);
//   }
// }
