// import { Component, OnInit } from '@angular/core';
// import { LoginService } from './login.service';
// import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// import { Router } from '@angular/router';

// @Component({
//   selector: 'app-login',
//   templateUrl: './login.component.html',
//   styleUrls: ['./login.component.css']
// })
// export class LoginComponent implements OnInit {
//   loginForm!: FormGroup;
//   // router: any;

//   constructor(private ls: LoginService, private fb: FormBuilder,private router:Router) {}

//   ngOnInit(): void {
//     // Initialize the form with form controls and validation
//     this.loginForm = this.fb.group({
//       email: ['', [Validators.required, Validators.email]],
//       password: ['', [Validators.required, Validators.minLength(6)]]
//     });
//   }

//   // onlogin(): void {
//   //   if (this.loginForm.valid) {
//   //     this.ls.loginData(this.loginForm.value).subscribe({
//   //       next: res => {
//   //         console.log('Response: ',res);
//   //         // alert("Login successful");

//   //         const token = res?.Token;
 
//   //         if (token) {
//   //           localStorage.setItem('adminToken', token);
//   //           alert('Login successful!');
//   //           this.router.navigate(['/home']);
//   //         }
//   //       },

//   //       error: err => {
//   //         console.error(err);
//   //         alert("Login failed");
//   //       }
//   //     });
//   //   } else {
//   //     alert("Please fill in all required fields correctly.");
//   //   }
//   // }

//   onlogin(): void {
//     if (this.loginForm.valid) {
//       this.ls.loginData(this.loginForm.value).subscribe({
//         next: res => {
//           console.log('Response:', res);
  
//           const token = res?.token;
//           if (token) {
//             localStorage.setItem('LoginToken', token);
//             console.log('Token saved:', token);
//             // alert("Login successful");
//             this.router.navigate(['/Home']);
//           } else {
//             console.error('Token not found in the response');
//             alert("Login failed: Token not found");
//           }
//         },
//         error: err => {
//           console.error('Login error:', err);
//           alert("Login failed");
//         }
//       });
//     } else {
//       alert("Please fill in all required fields correctly.");
//     }
//   }
  
// }

//----------------------------
//works

// import { Component, OnInit } from '@angular/core';
// import { LoginService } from './login.service';
// import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// import { Router } from '@angular/router';

// @Component({
//   selector: 'app-login',
//   templateUrl: './login.component.html',
//   styleUrls: ['./login.component.css']
// })
// export class LoginComponent implements OnInit {
//   loginForm!: FormGroup;
//   // router: any;

//   constructor(private ls: LoginService, private fb: FormBuilder,private router:Router) {}

//   ngOnInit(): void {
//     // Initialize the form with form controls and validation
//     this.loginForm = this.fb.group({
//       email: ['', [Validators.required, Validators.email]],
//       password: ['', [Validators.required, Validators.minLength(6)]]
//     });
//   }

//   // onlogin(): void {
//   //   if (this.loginForm.valid) {
//   //     this.ls.loginData(this.loginForm.value).subscribe({
//   //       next: res => {
//   //         console.log('Response: ',res);
//   //         // alert("Login successful");

//   //         const token = res?.Token;
 
//   //         if (token) {
//   //           localStorage.setItem('adminToken', token);
//   //           alert('Login successful!');
//   //           this.router.navigate(['/home']);
//   //         }
//   //       },

//   //       error: err => {
//   //         console.error(err);
//   //         alert("Login failed");
//   //       }
//   //     });
//   //   } else {
//   //     alert("Please fill in all required fields correctly.");
//   //   }
//   // }

//   onlogin(): void {
//     if (this.loginForm.valid) {
//       this.ls.loginData(this.loginForm.value).subscribe({
//         next: res => {
//           console.log('Response:', res);
  
//           const token = res?.token;
//           if (token) {
//             localStorage.setItem('LoginToken', token);
//             // localStorage.setItem('role', res.admin.role);
//             console.log('Token saved:', token);
//             // alert("Login successful");
//             this.router.navigate(['/Home']);
//           } else {
//             console.error('Token not found in the response');
//             alert("Login failed: Token not found");
//           }
//         },
//         error: err => {
//           console.error('Login error:', err);
//           alert("Login failed");
//         }
//       });
//     } else {
//       alert("Please fill in all required fields correctly.");
//     }
//   }
// }

// works ends
//--------------------------


import { Component, OnInit } from '@angular/core';
// import { LoginService } from './login.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;
  errorMessage: string | null = null;

  constructor(
    // private ls: LoginService, 
    private fb: FormBuilder,
    private router: Router,
    private http: HttpClient // Added HttpClient
  ) {}

  ngOnInit(): void {
    // Initialize the form with form controls and validation
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });

    this.checkLoggedIn();
  }
  //=====
  checkLoggedIn(): void {
    const role = localStorage.getItem('role');
    if (role) {
      // Navigate based on the stored role
      if (role === 'Owner') {
        this.router.navigate(['/Home']);
      } else if (role === 'Manager') {
        this.router.navigate(['/manager_link']);
      } else if (role === 'Receptionist') {
        this.router.navigate(['/receptionist_link']);
      }
    }
  }
  //=======


  //test

  onlogin(): void {
    if (this.loginForm.valid) {
      const loginData = this.loginForm.value;
  
      this.http.post<{ token: string, admin: any }>('http://localhost:5138/api/Auth/Login', loginData)
        .subscribe({
          next: (response) => {
            if (response?.admin?.role) {
              localStorage.setItem('token', response.token);
              localStorage.setItem('role', response.admin.role);
  
              // Navigate based on the role
              if (response.admin.role === 'Owner') {
                this.router.navigate(['/Home']);
              } else if (response.admin.role === 'Manager') {
                this.router.navigate(['/manager_link']);
              } else if (response.admin.role === 'Receptionist') {
                this.router.navigate(['/receptionist_link']);
              }
            } else {
              alert('Invalid credentials');
            }
          },
          error: (err) => {
            console.error('Error during login:', err); // Log error for debugging
            alert('Invalid credentials'); // Display for wrong credentials
          }
        });
    } 
  }
  
}


//works fine except invalid credentials-----------------------------

  // onlogin(): void {
  //   if (this.loginForm.valid) {
  //     const loginData = this.loginForm.value;
  
  //     // Log to see what the response looks like
  //     this.http.post<{ token: string, admin: any }>('http://localhost:5138/api/Admin/login', loginData)
  //       .subscribe({
  //         next: (response) => {
  //           console.log('API Response:', response);  // Log the full response for debugging
            
  //           // Ensure the 'admin' object and 'role' exist before accessing them
  //           if (response && response.admin && response.admin.role) {
  //             localStorage.setItem('token', response.token);
  //             localStorage.setItem('role', response.admin.role);
  //             // this.router.navigate(['/Home']);

  //             if (response.admin.role === 'Owner') {
  //               this.router.navigate(['/Home']); // Navigate to Manager dashboard
  //             } 
  
  //             if (response.admin.role === 'Manager') {
  //               this.router.navigate(['/manager_link']); // Navigate to Manager dashboard
  //             } 

  //             if (response.admin.role === 'Receptionist') {
  //               this.router.navigate(['/receptionist_link']); // Navigate to Manager dashboard
  //             } 

  //             sessionStorage.setItem('token', response.token);
  //           } else {
  //             console.error('Admin or role not found in the response');
  //             alert('Login failed: Admin role not found in the response');
  //           }
  //         },
  //         error: (err) => {
  //           console.error('Error during login:', err); // Log error for further debugging
  //           this.errorMessage = err.error.message || 'Login failed';
  //         }
  //       });
  //   } else {
  //     alert("Please fill in all required fields correctly.");
  //   }
  // }

  //works fine except invalid credentials-----------------------------
