import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RoomService {

  private url = 'http://localhost:5138/api/Rooms/All_Rooms';

  private del ='http://localhost:5138/api/Rooms/Delete';
  
  private create = 'http://localhost:5138/api/Rooms/Create';

  private update = 'http://localhost:5138/api/Rooms/Update';

  private available = 'http://localhost:5138/api/Rooms'

  constructor(private http: HttpClient) { }

  fetchRooms(): Observable<any[]> {
    return this.http.get<any>(this.url).pipe(
      map(response => response || []) 
    );
  }
  deleteRoom(room_Id: number): Observable<string> {
    return this.http.delete<string>(`${this.del}/${room_Id}`,{responseType:'text' as 'json'});
  }

  postRoom(body:any): Observable<any> {
    return this.http.post(this.create,body)
  }

  putRoom(id:number,body:any): Observable<any>{
    return this.http.put(`${this.update}/${id}`,body)
  }

  //test for available rooms
  fetchAvailableRooms(): Observable<any[]> {
    return this.http.get<any[]>(`${this.available}/Available`);
  }
  //test ends
}
