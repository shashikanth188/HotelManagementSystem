
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Guest } from './guest/guest.model';

@Injectable({
  providedIn: 'root'
})
export class GuestService {
  private apiUrl = 'http://localhost:5138/api/Guests';

  constructor(private http: HttpClient) {}

  getGuests(): Observable<Guest[]> {
    return this.http.get<Guest[]>(`${this.apiUrl}/All_Details`);
  }

  getGuestByEmail(email: string): Observable<Guest> {
    return this.http.get<Guest>(`${this.apiUrl}/Find_Guest`, { params: { email } });
  }

  createGuest(guest: Guest): Observable<Guest> {
    return this.http.post<Guest>(`${this.apiUrl}/Create`, guest);
  }

  updateGuest(id: number, guest: Guest): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/Update?id=${id}`, { id, ...guest });
  }

  deleteGuest(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/Delete`, { params: { id } });
  }

  //guest name dropdown in bills
  getGuestById(guestId: number): Observable<Guest> {
    return this.http.get<Guest>(`${this.apiUrl}/GetGuestById/${guestId}`);
  }


}
