import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit{
  title = 'hotelmanagement';
  token: string | null=null;
  constructor(private router:Router){
  
  }
  

  ngOnInit(): void {
    this.getrole();
    let token = localStorage.getItem('token');
    this.gettoken();
  }

  getrole(){
    let role=localStorage.getItem('role')
    // console.log(role);
    return role;
  }

  Logout(){
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    this.router.navigate(['']);
  }

  gettoken(){
    this.token=localStorage.getItem('token');
  }
  
}

