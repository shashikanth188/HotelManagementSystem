import { ComponentFixture, TestBed } from '@angular/core/testing';

import { unauthorizedComponent } from './unauthorized.component';

describe('OwnerComponent', () => {
  let component: unauthorizedComponent;
  let fixture: ComponentFixture<unauthorizedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [unauthorizedComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(unauthorizedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
