import { Component, OnInit } from '@angular/core';
import { Inventory } from './inventory.model';
import { InventoryService } from './inventory.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-inventory',
  templateUrl: './inventory.component.html',
  styleUrls: ['./inventory.component.css']
})
export class InventoryComponent implements OnInit {
  inventories: Inventory[] = [];
  inventory: Inventory = new Inventory(0, '', 0, 0);
  isEditing = false;
  inventory_Id!: 0;
    item_Name: '' = "";
    description: '' = "";
    quantity: '' = "";
    unit_Price:  undefined;
  constructor(private inventoryService: InventoryService,
    private snackbar:MatSnackBar
  ) {}

  ngOnInit(): void {
    this.loadInventories();
  }

  loadInventories(): void {
    this.inventoryService.getAllInventories().subscribe(data => {
      this.inventories = data;
    });
  }

  saveInventory(): void {
    if (this.isEditing) {
      this.inventoryService.updateInventory(this.inventory).subscribe(() => {
        this.loadInventories();
        this.resetForm();
        this.snackbar.open('Saved','Close',{
          duration:3000
        })
      });
    } else {
      this.inventoryService.createInventory(this.inventory).subscribe(() => {
        this.loadInventories();
        this.resetForm();
        this.snackbar.open('Inventory Added','Close',{
          duration:3000
        })
      });
    }
  }

  editInventory(inventory: Inventory): void {
    this.inventory = { ...inventory };
    this.isEditing = true;
  }

  deleteInventory(id: number): void {
    if(confirm('Are you sure want to delete inventory')){
      this.inventoryService.deleteInventory(id).subscribe(() => {
        this.loadInventories();
        this.snackbar.open('Deleted','Close',{
          duration:3000
        }
        )
      });
    }
    
  }

  resetForm(): void {
    this.inventory = new Inventory(0, '', 0, 0);
    this.isEditing = false;
  }
}
