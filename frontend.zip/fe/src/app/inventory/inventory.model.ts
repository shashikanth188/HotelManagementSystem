export class Inventory {
    inventory_Id: number;
    item_Name: string;
    description?: string;
    quantity: number;
    unit_Price: number;
  
    constructor(
      inventory_Id: number,
      item_Name: string,
      quantity: number,
      unit_Price: number,
      description?: string
    ) {
      this.inventory_Id = inventory_Id;
      this.item_Name = item_Name;
      this.description = description;
      this.quantity = quantity;
      this.unit_Price = unit_Price;
    }
  }
  