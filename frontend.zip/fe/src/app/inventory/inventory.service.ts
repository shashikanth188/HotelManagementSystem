import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Inventory } from './inventory.model';

@Injectable({
  providedIn: 'root'
})
export class InventoryService {
  private apiUrl = 'http://localhost:5138/api/Inventories';

  private create = 'http://localhost:5138/api/Inventories/Create';

  private update = 'http://localhost:5138/api/Inventories/Update';

  private delete = 'http://localhost:5138/api/Inventories/Delete';

  constructor(private http: HttpClient) {}

  getAllInventories(): Observable<Inventory[]> {
    return this.http.get<Inventory[]>(`${this.apiUrl}`);
  }

  getInventoryById(id: number): Observable<Inventory> {
    return this.http.get<Inventory>(`${this.apiUrl}/${id}`);
  }

  createInventory(inventory: Inventory): Observable<Inventory> {
    return this.http.post<Inventory>(`${this.create}/${inventory.inventory_Id}`, inventory);
  }

  updateInventory(inventory: Inventory): Observable<Inventory> {
    return this.http.put<Inventory>(`${this.update}/${inventory.inventory_Id}`, inventory);
  }

  deleteInventory(id: number): Observable<void> {
    return this.http.delete<void>(`${this.delete}/${id}`);
  }
}
