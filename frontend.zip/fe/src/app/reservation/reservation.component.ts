import { Component, OnInit } from '@angular/core';
import { ReservationService, Reservation } from './reservation.service';
import { GuestService } from '../guest.service';  // Import GuestService
import { RoomService } from '../room.service';    // Import RoomService
import { MatSnackBar } from '@angular/material/snack-bar';


@Component({
  selector: 'app-reservation',
  templateUrl: './reservation.component.html',
  styleUrls: ['./reservation.component.css']
})
export class ReservationComponent implements OnInit {
  reservations: Reservation[] = [];
  guests: any[] = [];  // Store list of guests
  filteredGuests: any[] = []; // For filtered guest list
  availableRooms: any[] = [];  // Store available rooms
  selectedReservation: Reservation | null = null;
  guestSearch: string = '';  // To store the search query
  isEditing: boolean = false;
  minDate: string | undefined;

  constructor(
    private reservationService: ReservationService,
    private guestService: GuestService,  // Inject GuestService
    private roomService: RoomService,     // Inject RoomService
    private snackbar:MatSnackBar
  ) {}

  ngOnInit(): void {
    this.loadReservations();
    this.loadGuests();  // Fetch guests
    this.loadAvailableRooms();  // Fetch available rooms

    //previous date block
    const today = new Date();
    const year = today.getFullYear();
    const month = ('0' + (today.getMonth() + 1)).slice(-2); // Months are zero-based
    const day = ('0' + today.getDate()).slice(-2);

    this.minDate = `${year}-${month}-${day}`;
  }

  loadReservations() {
    this.reservationService.getReservations().subscribe((data) => {
      this.reservations = data;
    });
  }

  loadGuests() {
    this.guestService.getGuests().subscribe((data) => {
      this.guests = data;
      this.filteredGuests = this.guests; // Initially show all guests
    });
  }

  loadAvailableRooms() {
    this.roomService.fetchAvailableRooms().subscribe((data) => {
      this.availableRooms = data;
    });
  }

  // Filtering function for guests
 // Filtering function for guests
filterGuests(query: string) {
  this.guestSearch = query;
  if (query) {
    this.filteredGuests = this.guests.filter(guest =>
      guest.name.toLowerCase().includes(query.toLowerCase()) ||
      guest.email.toLowerCase().includes(query.toLowerCase())
    );
  } else {
    this.filteredGuests = [];
  }
}

// Select guest from the filtered list
selectGuest(guest: any) {
  this.selectedReservation!.guest_Id = guest.guest_Id;
  this.guestSearch = `${guest.name} (${guest.email})`;  // Set the input value to the selected guest
  this.filteredGuests = [];  // Clear the filtered list once a guest is selected
}


  createNewReservation() {
    this.selectedReservation = {
      reservation_Id: 0,
      guest_Id: 0,
      room_Id: 0,
      checkInDate: new Date(),
      checkOutDate: new Date(),
      no_Guest: 1,
      status: 'Pending',
    };
    this.isEditing = false;
  }

  editReservation(reservation: Reservation) {
    this.selectedReservation = { ...reservation };
    this.isEditing = true;
  }

  saveReservation() {
    if (this.isEditing && this.selectedReservation?.reservation_Id) {
      this.reservationService
        .updateReservation(this.selectedReservation.reservation_Id, this.selectedReservation)
        .subscribe(() => this.loadReservations());
        this.snackbar.open('Reservation updated successfully!', 'Close', {
          duration: 3000, // Duration in milliseconds
        })
    } else {
      this.reservationService
        .createReservation(this.selectedReservation!)
        .subscribe(() => this.loadReservations());
        this.snackbar.open('Reservation created successfully!', 'Close', {
          duration: 3000, // Duration in milliseconds
        });
    }
    this.selectedReservation = null;
  }

  deleteReservation(id: number) {
    if (confirm('Are you sure you want to delete this reservation?')) {
      this.reservationService.deleteReservation(id).subscribe(() => {
        this.loadReservations();
      });
    }
  }

  cancelEdit() {
    this.selectedReservation = null;
  }

  // Disable buttons for past checkout dates
  isPastCheckOutDate(checkOutDate: Date): boolean {
    const today = new Date();
    return new Date(checkOutDate) < today;
  }
}