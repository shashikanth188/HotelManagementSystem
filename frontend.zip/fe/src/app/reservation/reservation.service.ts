import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
// import { Observable } from 'rxjs';
//test 1 for guest name dropdown
import { Observable, forkJoin } from 'rxjs';
// import { Reservation } from './reservation.service';
import { GuestService } from '../guest.service';
import { map, switchMap } from 'rxjs/operators';
import {Guest} from '../guest/guest.model';
//test 1 end


export interface Reservation {
  reservation_Id: number;
  guest_Id: number;
  room_Id: number;
  checkInDate: Date;
  checkOutDate: Date;
  no_Guest: number;
  status: string;
}

@Injectable({
  providedIn: 'root',
})
export class ReservationService {
  private apiUrl = 'http://localhost:5138/api/Reservations';

  private update = 'http://localhost:5138/api/Reservations/Update';

  private create = 'http://localhost:5138/api/Reservations/Create';

  private delete = 'http://localhost:5138/api/Reservations/Delete';

  
  
  // constructor(private http: HttpClient) {}

  // test
  constructor(private http: HttpClient, private guestService: GuestService) {}

  getReservationsWithGuestName(): Observable<any[]> {
    return this.http.get<Reservation[]>(`${this.apiUrl}/All_Reservations`).pipe(
      switchMap(reservations => {
        // Map through all reservations and for each reservation, get the guest details by guest_Id
        const reservationWithGuestNameObservables = reservations.map(reservation => 
          this.guestService.getGuestById(reservation.guest_Id).pipe(
            map(guest => ({
              ...reservation,
              guestName: guest.name // Adding guestName to each reservation object
            }))
          )
        );
        return forkJoin(reservationWithGuestNameObservables);
      })
    );
  }


  //test



  getReservations(): Observable<Reservation[]> {
    return this.http.get<Reservation[]>(`${this.apiUrl}`);
  }

  getReservationById(id: number): Observable<Reservation> {
    return this.http.get<Reservation>(`${this.apiUrl}/${id}`);
  }

  createReservation(reservation: Reservation): Observable<any> {
    return this.http.post<Reservation>(this.create, reservation);
  }

  updateReservation(id: number, reservation: Reservation): Observable<void> {
    return this.http.put<void>(`${this.update}/${id}`, reservation);
  }

  deleteReservation(id: number): Observable<void> {
    return this.http.delete<void>(`${this.delete}/${id}`);
  }
}
