
import { Component, OnInit } from '@angular/core';
import { GuestService } from '../guest.service';
import { Guest } from './guest.model';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-guest',
  templateUrl: './guest.component.html',
  styleUrls: ['./guest.component.css']
})
export class GuestComponent implements OnInit {
  searchEmail: string = '';
  foundGuest: Guest | null = null;
  guests: Guest[] = [];
  newGuest: Guest = new Guest();
  selectedGuest: Guest | null = null;
  showGuestList: boolean = false; // Control visibility of the guest list

  constructor(private guestService: GuestService,
    private snackbar:MatSnackBar
  ) {}

  ngOnInit(): void {
    // Initial data load if necessary
  }

  loadGuests(): void {
    this.guestService.getGuests().subscribe(data => {
      this.guests = data;
    });
  }

  findGuestByEmail(email: string): void {
    this.guestService.getGuestByEmail(email).subscribe(guest => {
      if (guest) {
        this.foundGuest = guest;
        console.log('Guest found:', guest);
      } else {
        console.log('No guest found with that email.');
      }
    });
  }

  createGuest(): void {
    this.guestService.createGuest(this.newGuest).subscribe(guest => {
      this.guests.push(guest);
      this.newGuest = new Guest(); // Reset form
      this.snackbar.open('Guest Details Saved successfully!', 'Close', {
        duration: 3000, // Duration in milliseconds
      })
    });
  }

  toggleGuestList(): void {
    this.showGuestList = !this.showGuestList; // Toggle visibility
    if (this.showGuestList) {
      this.loadGuests(); // Load guests if showing the list
    }
  }

  deleteGuest(id: number): void {
    if (confirm('Are you sure you want to delete this guest?')) {
      this.guestService.deleteGuest(id).subscribe(() => {
        this.guests = this.guests.filter(g => g.guest_Id !== id);
        this.snackbar.open('Guest Details Deleted!', 'Close', {
          duration: 3000, // Duration in milliseconds
        })
      });
    }
  }

  editGuest(guest: Guest): void {
    this.selectedGuest = { ...guest };
  }

  updateGuest(guest: Guest): void {
    if (guest.guest_Id) {
      this.guestService.updateGuest(guest.guest_Id, guest).subscribe(() => {
        // console.log('Guest updated successfully');
        this.loadGuests();
        this.closeModal();
        this.snackbar.open('Details Updated','Close',{
          duration:3000
        })
      });
    }
  }

  closeModal(): void {
    this.selectedGuest = null; // Close modal
  }
  
}
