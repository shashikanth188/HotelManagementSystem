export class Guest {
    guest_Id?: number;
    name: string = '';
    email: string = '';
    gender: string = '';
    address: string = '';
    phoneNo: string = '';
  }
  