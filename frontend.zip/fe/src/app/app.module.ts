import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';


import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { HomeComponent } from './home/home.component';
import { RoomComponent } from './room/room.component';
import { GuestComponent } from './guest/guest.component';
import { InventoryComponent } from './inventory/inventory.component';
import { ReservationComponent } from './reservation/reservation.component';
import { StaffComponent } from './staff/staff.component';
import { ReportComponent } from './report/report.component';
import { BillsComponent } from './bills/bills.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AuthInterceptor } from './auth.interceptor';
import { unauthorizedComponent } from './unauthorized/unauthorized.component';
import { ManagerComponent } from './manager/manager.component';
import { ReceptionistComponent } from './receptionist/receptionist.component';
import { NotfoundComponent } from './notfound/notfound.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';


@NgModule({
  declarations: [
    AppComponent,
    RoomComponent,
    HomeComponent,
    GuestComponent,
    InventoryComponent,
    ReservationComponent,
    StaffComponent,
    ReportComponent,
    BillsComponent,
    LoginComponent,
    DashboardComponent,
    ManagerComponent,
    ReceptionistComponent,
    NotfoundComponent,
    unauthorizedComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
  
  ],
  providers: [
    provideClientHydration(),
    {
      provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor,multi:true
    },
    provideAnimationsAsync()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }