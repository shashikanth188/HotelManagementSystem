export class Staff {
    staff_ID: number=0;
    staff_Name: string | undefined;
    age: number | undefined;
    address: string | undefined;
    salary: number | undefined;
    designation: string | undefined;
    email: string | undefined;
    staff_Code: string | undefined;
  }
  