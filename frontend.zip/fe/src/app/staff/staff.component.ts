import { Component, OnInit } from '@angular/core';
import { StaffService } from './staff.service';
import { Staff } from './staff.model';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-staff',
  templateUrl: './staff.component.html',
  styleUrls: ['./staff.component.css']
})
export class StaffComponent implements OnInit {
  staffs: Staff[] = [];
  staff: Staff = new Staff();
  isEditMode: boolean = false;
  isModalOpen: boolean = false; // Add this property

  constructor(private staffService: StaffService,
    private snackbar:MatSnackBar
  ) {}

  ngOnInit(): void {
    this.getStaffs();
  }

  getStaffs(): void {
    this.staffService.getStaffs().subscribe((data: Staff[]) => {
      this.staffs = data;
    });
  }

  editStaff(staff: Staff): void {
    this.staff = { ...staff };
    this.isEditMode = true;
    window.scrollTo(0, 0);
  }

  deleteStaff(id: number): void {
    if (confirm('Are you sure you want to delete this reservation?')){
    this.staffService.deleteStaff(id).subscribe(() => {
      this.staffs = this.staffs.filter(staff => staff.staff_ID !== id);
      this.snackbar.open('Staff deleted Successfully!','Close',{
        duration:3000,
      })
    });
  }
  }

  onSubmit(): void {
    if (this.isEditMode) {
      this.staffService.updateStaff(this.staff.staff_ID, this.staff).subscribe(() => {
        this.getStaffs();
        this.resetForm();
        this.snackbar.open('Updated Successfully!', 'Close',{
          duration:3000
        })
      });
    } else {
      this.staffService.createStaff(this.staff).subscribe(() => {
        this.getStaffs();
        this.resetForm();
        this.snackbar.open('Staff created Successfully', 'Close',{
          duration:3000
        }
        )
      });
    }
  }

  resetForm(): void {
    this.staff = new Staff();
    this.isEditMode = false;
  }

  openModal(): void {
    this.isModalOpen = true;
  }

  closeModal(event: Event): void {
    // Stop event from propagating to avoid closing the modal when clicking inside
    event.stopPropagation();
    this.isModalOpen = false;
  }
}
