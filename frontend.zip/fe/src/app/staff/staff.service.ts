import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Staff } from './staff.model';

@Injectable({
  providedIn: 'root'
})
export class StaffService {
  private apiUrl = 'http://localhost:5138/api/Staff';

  private create = 'http://localhost:5138/api/Staff/Create/';

  private update = 'http://localhost:5138/api/Staff/Update';

  private delete = 'http://localhost:5138/api/Staff/Delete';

  constructor(private http: HttpClient) {}

  getStaffs(): Observable<Staff[]> {
    return this.http.get<Staff[]>(`${this.apiUrl}`);
  }

  getStaffById(id: number): Observable<Staff> {
    return this.http.get<Staff>(`${this.apiUrl}/${id}`);
  }

  createStaff(staff: Staff): Observable<any> {
    return this.http.post<Staff>(this.create, staff);
  }

  updateStaff(id: number, staff: Staff): Observable<void> {
    return this.http.put<void>(`${this.update}/${id}`, staff);
  }

  deleteStaff(id: number): Observable<void> {
    return this.http.delete<void>(`${this.delete}/${id}`);
  }
}
