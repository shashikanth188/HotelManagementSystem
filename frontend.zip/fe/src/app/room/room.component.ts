import { Component, OnInit } from '@angular/core';
import { RoomService } from '../room.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-room',
  templateUrl: './room.component.html',
  styleUrls: ['./room.component.css']  
})
export class RoomComponent implements OnInit {
  rooms: any[] = [];  

  constructor(private rs: RoomService,
    private snackbar:MatSnackBar
  ) {}

  formHeader = "Add Room";
  roomNumber:any;
  roomType="";
  // roomDescription="";
  status="";
  showForm=false;
  room_Id=null;//
//Get Rooms
  ngOnInit(): void {
    this.getRooms()
  }
  
  getRooms(){
    this.rs.fetchRooms().subscribe(
      (data: any[]) => {
        // console.log(data);
        this.rooms = data;  
      },
      error => console.error('Error fetching data', error)
    )
  }

//Delete Room by RoomId
  // deleteRoom(room_Id: number): void {
  //   this.rs.deleteRoom(room_Id).subscribe(
  //     response => {
  //       console.log('Delete response:', response);  
  //       this.getRooms();  // Refresh the list of rooms
  //     },
  //     error => {
  //       console.error('Error deleting room', error);
        
  //     }
  //   );
  // }


  deleteRoom(room_Id: number): void {
    // Display a confirmation dialog
    const confirmed = window.confirm('Are you sure you want to delete this room?');
  
    // Proceed only if the user confirms
    if (confirmed) {
      this.rs.deleteRoom(room_Id).subscribe(
        response => {
          // console.log('Delete response:', response);  
          this.getRooms();  // Refresh the list of rooms
          this.snackbar.open('Deleted Successfully','Close',{
            duration:3000
          })
        },
        error => {
          console.error('Error deleting room', error);
        }
      );
    }
  }
  


  openForm(data:any=null){
    this.showForm=true;
    if(data){
      this.roomNumber=data.roomNumber;
      this.roomType=data.roomType;
      // this.roomDescription=data.roomDescription;
      this.status=data.status;
      this.room_Id=data.room_Id;//
      this.formHeader="Edit Room";
    }
    else{
      this.room_Id=null;//
      this.formHeader="Add Room";
    }
  }
  
  closeForm(){
    this.showForm = false;
    this.clearForm();
  }
  clearForm(){
      this.roomNumber=null;
      this.roomType="";
      // this.roomDescription="";
      this.status="";
  }
  saveRoom(){
    this.showForm=false;

    let body:any={
      roomNumber:this.roomNumber,
      roomType:this.roomType,
      // roomDescription:this.roomDescription,
      status:this.status
    }
    if(this.room_Id){//
      body['room_Id']=this.room_Id;
      this.rs.putRoom(this.room_Id,body).subscribe(
        (res)=>{
          this.getRooms();
          this.snackbar.open('Saved successfully','Close',{
            duration:3000
          })
        }        
      )
    }
    else{
      this.rs.postRoom(body).subscribe(
        (res)=>{
          this.getRooms();
          this.snackbar.open('Saved successfully','Close',{
            duration:3000
          })
        }
      )
    }
  }

}
