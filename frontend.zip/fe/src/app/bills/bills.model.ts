export interface BillDTO {
  bill_Id?: number;
  reservation_Id: number;
  price: number;
  tax: number;
  totalAmount?: number;
}
  