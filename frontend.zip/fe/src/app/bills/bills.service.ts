import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BillDTO } from './bills.model';

@Injectable({
  providedIn: 'root'
})
export class BillService {
  getBillById(billId: number) {
    throw new Error('Method not implemented.');
  }
  private baseUrl = 'http://localhost:5138/api/Bill';

  constructor(private http: HttpClient) { }

  getBills(): Observable<BillDTO[]> {
    return this.http.get<BillDTO[]>(`${this.baseUrl}/All_Details`);
  }

  getBillByEmail(email: string): Observable<BillDTO> {
    return this.http.get<BillDTO>(`${this.baseUrl}/FindByGuestEmail?email=${email}`);
  }

  // createBill(bill: BillDTO): Observable<BillDTO> {
  //   return this.http.post<BillDTO>(`${this.baseUrl}/Create/${bill}`, bill);
  // }

  createBill(bill: BillDTO): Observable<BillDTO> {
    return this.http.post<BillDTO>(`${this.baseUrl}/Create`, bill);
  }
  
  

  updateBill(id: number, bill: BillDTO): Observable<void> {
    return this.http.put<void>(`${this.baseUrl}/Update?id=${id}`, bill);
  }

  deleteBill(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/Delete?id=${id}`);
  }
}
