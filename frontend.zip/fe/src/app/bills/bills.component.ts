import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BillService } from './bills.service';
import { BillDTO } from './bills.model';
import { ReservationService, Reservation } from '../reservation/reservation.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-bills',
  templateUrl: './bills.component.html',
  styleUrls: ['./bills.component.css']
})
export class BillsComponent implements OnInit {
  bills: BillDTO[] = [];
  billForm: FormGroup;
  selectedBill: BillDTO | null = null;
  pendingReservations: Reservation[] = [];
  showModal = false; // To control the modal visibility

  constructor(
    private billService: BillService,
    private fb: FormBuilder,
    private reservationService: ReservationService,
    private snackbar: MatSnackBar
  ) {
    this.billForm = this.fb.group({
      reservation_Id: ['', Validators.required],
      price: ['', [Validators.required, Validators.min(0)]],
      tax: ['', [Validators.required, Validators.min(0)]],
      totalAmount: [{ value: '0', disabled: true }],
      paymentMode: ['cash', Validators.required],
      cardNumber: [''],
      expiryDate: [''],
      cvv: ['']
    });

    // Calculate total amount on price or tax change
    this.billForm.get('price')?.valueChanges.subscribe(() => this.calculateTotalAmount());
    this.billForm.get('tax')?.valueChanges.subscribe(() => this.calculateTotalAmount());

    // Handle form changes when the payment mode is switched
    this.billForm.get('paymentMode')?.valueChanges.subscribe(mode => {
      if (mode === 'card') {
        this.billForm.get('cardNumber')?.setValidators([Validators.required]);
        this.billForm.get('expiryDate')?.setValidators([Validators.required]);
        this.billForm.get('cvv')?.setValidators([Validators.required, Validators.minLength(3), Validators.maxLength(4)]);
      } else {
        this.billForm.get('cardNumber')?.clearValidators();
        this.billForm.get('expiryDate')?.clearValidators();
        this.billForm.get('cvv')?.clearValidators();
      }
      this.billForm.get('cardNumber')?.updateValueAndValidity();
      this.billForm.get('expiryDate')?.updateValueAndValidity();
      this.billForm.get('cvv')?.updateValueAndValidity();
    });

  }

  ngOnInit(): void {
    this.getBills();
    this.getPendingReservations();
  }

  getBills(): void {
    this.billService.getBills().subscribe(bills => this.bills = bills);
  }

  getPendingReservations(): void {
    this.reservationService.getReservations().subscribe(reservations => {
      this.pendingReservations = reservations.filter(reservation => reservation.status === 'Pending');
    });
  }

  createBill(): void {
    if (this.billForm.valid) {
      this.billForm.get('totalAmount')?.enable();
      const billData: BillDTO = {
        bill_Id: undefined,
        reservation_Id: this.billForm.get('reservation_Id')?.value,
        price: this.billForm.get('price')?.value,
        tax: this.billForm.get('tax')?.value,
        totalAmount: this.billForm.get('totalAmount')?.value
      };

      this.billService.createBill(billData).subscribe(
        response => {
          this.bills.push(response);
          this.updateReservationStatus(billData.reservation_Id);
          this.resetForm();
          this.snackbar.open('Bill created successfully!', 'Close', {
            duration: 3000, // Duration in milliseconds
          });
        },
        error => console.error('Error creating bill:', error)
      );
    } else {
      console.error('Form is not valid');
    }
  }

  updateBill(): void {
    if (this.billForm.valid && this.selectedBill) {
      const updatedBill: BillDTO = {
        bill_Id: this.selectedBill.bill_Id,
        reservation_Id: this.billForm.get('reservation_Id')?.value,
        price: this.billForm.get('price')?.value,
        tax: this.billForm.get('tax')?.value,
        totalAmount: this.billForm.get('totalAmount')?.value
      };

      this.billService.updateBill(this.selectedBill.bill_Id!, updatedBill).subscribe(() => {
        this.getBills();
        this.resetForm();
      });
    }
  }

  onEdit(bill: BillDTO): void {
    this.billForm.patchValue(bill);
    this.selectedBill = bill;
  }

  onDelete(id: number): void {
    this.billService.deleteBill(id).subscribe(() => this.getBills());
  }

  private calculateTotalAmount(): void {
    const price = this.billForm.get('price')?.value || 0;
    const tax = this.billForm.get('tax')?.value || 0;
    this.billForm.get('totalAmount')?.setValue(price + tax, { emitEvent: false });
  }

  private resetForm(): void {
    this.billForm.reset({ paymentMode: 'cash' });
    this.selectedBill = null;
  }

  updateReservationStatus(reservationId: number): void {
    this.reservationService.getReservationById(reservationId).subscribe(reservation => {
      reservation.status = 'Booked';
      this.reservationService.updateReservation(reservationId, reservation).subscribe(
        () => console.log('Reservation status updated to Booked'),
        error => console.error('Error updating reservation status:', error)
      );
    });
  }

  openModal(): void {
    this.showModal = true;
  }

  closeModal(): void {
    this.showModal = false;
  }
}