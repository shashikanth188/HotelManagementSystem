import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RoomComponent } from './room/room.component';
import { HomeComponent } from './home/home.component';
import { GuestComponent } from './guest/guest.component';
import { InventoryComponent } from './inventory/inventory.component';
import { ReservationComponent } from './reservation/reservation.component';
import { StaffComponent } from './staff/staff.component';
import { ReportComponent } from './report/report.component';
import { BillsComponent } from './bills/bills.component';
import { LoginComponent } from './login/login.component';
import { ManagerComponent } from './manager/manager.component';
import { ReceptionistComponent } from './receptionist/receptionist.component';
import { AuthGuard } from './auth.guard';
import { NotfoundComponent } from './notfound/notfound.component';
import { unauthorizedComponent } from './unauthorized/unauthorized.component';

const routes: Routes = [
  
  {
    path:'login-link',component:LoginComponent
  },
  {
    path:'', redirectTo:'login-link',pathMatch:'full'
  },
  {
    path:'Home', component:HomeComponent, canActivate: [AuthGuard], data:{role: 'Owner'}
  },
  {
    path:'room_link',component:RoomComponent, canActivate: [AuthGuard], data:{role: 'Manager'}
  },
  {
    path:'guest_link', component: GuestComponent, canActivate: [AuthGuard], data:{role: 'Receptionist'}
  },
  {
    path:'inventory-link', component:InventoryComponent, canActivate: [AuthGuard], data:{role: 'Manager'}
  },
  {
    path:'reservation-link', component:ReservationComponent, canActivate: [AuthGuard], data:{role: 'Receptionist'}
  },
  {
    path:'staff-link', component:StaffComponent, canActivate: [AuthGuard], data:{role: 'Manager'}
  },
  {
    path:'report-link', component:ReportComponent, canActivate: [AuthGuard], data:{role: 'Owner'}
  },
  {
    path:'bills-link', component:BillsComponent, canActivate: [AuthGuard], data:{role: 'Receptionist'}
  },

  {
    path:'manager_link', component:ManagerComponent, canActivate: [AuthGuard], data:{role: 'Manager'}
  },
  {
    path:'receptionist_link', component:ReceptionistComponent, canActivate: [AuthGuard], data:{role: 'Receptionist'}
  },
  {
    path:'unauthorized', component:unauthorizedComponent, canActivate: [AuthGuard]
  },
  {
    path:'**', component:NotfoundComponent
  }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
