using HotelManagementSystem.Models;
using Microsoft.EntityFrameworkCore;
public class ReportService
{
    private readonly AppDbContext _context;
    public ReportService(AppDbContext context)
    {
        _context = context;
    }

    public async Task<double> GetMonthlyRevenueAsync(DateTime date)
    {
        var startOfMonth = new DateTime(date.Year, date.Month, 1);
        var endOfMonth = startOfMonth.AddMonths(1);

        var revenue = await _context.Bills
            .Where(b => b.Reservation.CheckInDate >= startOfMonth && b.Reservation.CheckInDate < endOfMonth)
            .SumAsync(b => b.TotalAmount);

        return revenue;
    }
    //works (perfect)
    public async Task<double> GetYearlyRevenueAsync(int year)
    {
        var startOfYear = new DateTime(year, 1, 1);
        var endOfYear = startOfYear.AddYears(1);

        var revenue = await _context.Bills
            .Where(b => b.Reservation.CheckInDate >= startOfYear && b.Reservation.CheckInDate < endOfYear)
            .SumAsync(b => b.TotalAmount);

        return revenue;
    }


    //works but only revenue of all the months 
//     public async Task<Dictionary<int, double>> GetYearlyRevenueAsync(int year)
// {
//     var startOfYear = new DateTime(year, 1, 1);
//     var endOfYear = startOfYear.AddYears(1);

//     // Initialize a dictionary to store revenue for each month
//     var monthlyRevenue = new Dictionary<int, double>();

//     // Loop through each month
//     for (int month = 1; month <= 12; month++)
//     {
//         var startOfMonth = new DateTime(year, month, 1);
//         var endOfMonth = startOfMonth.AddMonths(1);

//         // Calculate revenue for the current month
//         var revenue = await _context.Bills
//             .Where(b => b.Reservation.CheckInDate >= startOfMonth && b.Reservation.CheckInDate < endOfMonth)
//             .SumAsync(b => b.TotalAmount);

//         // Add the revenue to the dictionary
//         monthlyRevenue[month] = revenue;
//     }

//     return monthlyRevenue;
// }



//     public async Task<(Dictionary<int, double> MonthlyRevenue, double TotalYearlyRevenue)> GetYearlyRevenueAsync(int year)
// {
//     var startOfYear = new DateTime(year, 1, 1);
//     var endOfYear = startOfYear.AddYears(1);

//     var monthlyRevenue = new Dictionary<int, double>();
//     double totalYearlyRevenue = 0;

//     // Loop through each month
//     for (int month = 1; month <= 12; month++)
//     {
//         var startOfMonth = new DateTime(year, month, 1);
//         var endOfMonth = startOfMonth.AddMonths(1);

//         // Calculate revenue for the current month
//         var revenue = await _context.Bills
//             .Where(b => b.Reservation.CheckInDate >= startOfMonth && b.Reservation.CheckInDate < endOfMonth)
//             .SumAsync(b => b.TotalAmount);

//         // Add the revenue to the dictionary and the total sum
//         monthlyRevenue[month] = revenue;
//         totalYearlyRevenue += revenue;
//     }

//     return (monthlyRevenue, totalYearlyRevenue);
// }



    public async Task<double> GetRevenueByRangeAsync(DateTime fromDate, DateTime toDate)
    {
        var revenue = await _context.Bills
            .Where(b => b.Reservation.CheckInDate >= fromDate && b.Reservation.CheckInDate <= toDate)
            .SumAsync(b => b.TotalAmount);

        return revenue;
    }
}
