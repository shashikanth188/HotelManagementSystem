using System.ComponentModel.DataAnnotations;

public class Inventory
{
    [Key]
    public int Inventory_Id{get; set;}
    [Required]
    public string Item_Name{get; set;}
    
    public string Description{get; set;}
    [Required]
    public int Quantity{get; set;}
    [Required]
    public double Unit_Price{get; set;}
}