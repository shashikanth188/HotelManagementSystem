using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
public class Reservation
{
    [Key]
    public int Reservation_Id{get; set;}
    [ForeignKey("Guest")]
    public int Guest_Id{get; set;}
    [ForeignKey("Room")]
    public int Room_Id{get; set;}
    [Required]
    [DataType(DataType.Date)]
    //[FutureDate(ErrorMessage = "Check-in date must be in the future.")]
    public DateTime CheckInDate{get; set;}
    [Required]
    [DataType(DataType.Date)]
    //[FutureDate(ErrorMessage = "Check-out date must be in the future.")]
    //[CheckOutDateGreaterThanCheckInDate(ErrorMessage = "Check-out date must be later than check-in date.")]
    public DateTime CheckOutDate{get; set;}
    [Required]
    public int No_Guest{get; set;}
    [Required]
    public string Status{get; set;}
 
    public virtual Guest Guest{get; set;}
    public virtual Room Room {get; set;}

     public virtual ICollection<Bill> Bills { get; set; } = new HashSet<Bill>();


     //validations
//      public class FutureDateAttribute : ValidationAttribute
// {
//     protected override ValidationResult IsValid(object value, ValidationContext validationContext)
//     {
//         if (value is DateTime dateTime)
//         {
//             if (dateTime <= DateTime.Now.Date)
//             {
//                 return new ValidationResult(ErrorMessage ?? "The date must be in the future.");
//             }
//         }

//         return ValidationResult.Success;
//     }
// }

// public class CheckOutDateGreaterThanCheckInDateAttribute : ValidationAttribute
// {
//     protected override ValidationResult IsValid(object value, ValidationContext validationContext)
//     {
//         var reservation = (Reservation)validationContext.ObjectInstance;

//         if (reservation.CheckOutDate <= reservation.CheckInDate)
//         {
//             return new ValidationResult(ErrorMessage ?? "Check-out date must be later than check-in date.");
//         }

//         return ValidationResult.Success;
//     }
// }
}
 