using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
public class Bill
{
    [Key]
    public int Bill_Id{get; set;}

    [ForeignKey("Reservation")]
    public int Reservation_Id{get; set;}
    [Required]
    public double Price{get; set;}
    [Required]
    public double Tax{get; set;}
    
    public double TotalAmount{get; set;}

    public virtual Reservation Reservation {get; set;}
}