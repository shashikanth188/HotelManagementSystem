using System.ComponentModel.DataAnnotations;
public class Staff
{
    [Key]
    public int Staff_ID{get; set;}
    [Required]
    public string Staff_Name{get; set;}
    [Required]
    public int Age{get; set;}
    [Required]
    public string Address{get; set;}
    [Required]
    public double Salary{get; set;}
    [Required]
    public string Designation{get; set;}
    [Required]
    public string Email{get; set;} 
    [Required]
    public string Staff_Code{get; set;}
} 