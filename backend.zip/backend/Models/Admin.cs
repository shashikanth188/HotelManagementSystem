using System.ComponentModel.DataAnnotations;

public class Admin
{
    [Key]
    public int User_Id{get; set;}
    
    [Required]
    
    public string UserName{get; set;}

    [Required]
    [DataType(DataType.EmailAddress)]
    // [RegularExpression(
    //     @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$",
    //     ErrorMessage = "Invalid email address format.")]
    public string EmailId{get; set;}
    
    [StringLength(250, MinimumLength =6)]
    [DataType(DataType.Password)]
    [Required(ErrorMessage ="Password is required")]
    // [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$",
    //  ErrorMessage = "The password must be at least 8 characters long, and must include at least one uppercase letter, one lowercase letter, one number, and one special character.")]
    public string Password{get; set;}
    [Required]
    [DataType(DataType.Text)]
    public string Role{get; set;}

    //[Required]
    //public AdminRole Role { get; set; }
}