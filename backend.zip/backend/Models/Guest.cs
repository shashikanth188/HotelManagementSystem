using System.ComponentModel.DataAnnotations;
public class Guest
{
    [Key]
    public int Guest_Id{get; set;}
    [Required]
    [StringLength(30, MinimumLength = 4)]
    public string Name{get; set;}
    [Required]
    [DataType(DataType.EmailAddress)]
    // [RegularExpression(@"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$",
    // ErrorMessage = "Invalid email address format.")]
    public string Email{get; set;}
    public string Gender{get; set;}
    [Required]
    public string Address{get; set;}
    [Required]
    public string PhoneNo{get; set;}
    public virtual ICollection<Reservation> Reservation {get; set;} = new HashSet<Reservation>();
}
