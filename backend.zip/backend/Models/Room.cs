using System.ComponentModel.DataAnnotations;
public class Room
{
    [Key]
    public int Room_Id{get; set;}
    [Required]
    public int RoomNumber{get; set;}
    [Required]
    public string RoomType{get; set;}
    
    [Required]
    public string Status{get; set;}
    //public decimal TotalAmount{get; set;}

    public virtual ICollection<Reservation> Reservation {get; set;} = new HashSet<Reservation>();
}