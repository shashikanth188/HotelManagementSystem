using HotelManagementSystem.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HotelManagementSystem.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Owner,Receptionist")]
    public class ReservationsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public ReservationsController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/Reservations
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ReservationDTO>>> GetReservations()
        {
            var reservations = await _context.Reservations
                .Include(r => r.Guest)
                .Include(r => r.Room)
                .Select(r => new ReservationDTO
                {
                    Reservation_Id = r.Reservation_Id,
                    Guest_Id = r.Guest_Id,
                    Room_Id = r.Room_Id,
                    CheckInDate = r.CheckInDate,
                    CheckOutDate = r.CheckOutDate,
                    No_Guest = r.No_Guest,
                    Status = r.Status,
                    // Price = r.Price,
                    // Tax = r.Tax,
                    // TotalAmount = r.TotalAmount,
                    
                })
                .ToListAsync();

            return Ok(reservations);
        }

        // GET: api/Reservations/5
        // [HttpGet("FindById")]
        // public async Task<ActionResult<ReservationDTO>> GetReservation(int id)
        // {
        //     var reservation = await _context.Reservations
        //         .Include(r => r.Guest)
        //         .Include(r => r.Room)
        //         .Where(r => r.Reservation_Id == id)
        //         .Select(r => new ReservationDTO
        //         {
        //             Reservation_Id = r.Reservation_Id,
        //             Guest_Id = r.Guest_Id,
        //             Room_Id = r.Room_Id,
        //             CheckInDate = r.CheckInDate,
        //             CheckOutDate = r.CheckOutDate,
        //             No_Guest = r.No_Guest,
        //             Status = r.Status,
        //             // Price = r.Price,
        //             // Tax = r.Tax,
        //             // TotalAmount = r.TotalAmount,
                    
        //         })
        //         .FirstOrDefaultAsync();

        //     if (reservation == null)
        //     {
        //         return NotFound();
        //     }

        //     return Ok(reservation);
        // }

        //find by email
        //-----------------works----------------

    [HttpGet("FindByEmail")]
    public async Task<ActionResult<ReservationDTO>> GetReservation(string email)
    {
    var reservation = await _context.Reservations
        .Include(r => r.Guest)
        .Include(r => r.Room)
        .Where(r => r.Guest.Email == email)
        .Select(r => new ReservationDTO
        {
            Reservation_Id = r.Reservation_Id,
            Guest_Id = r.Guest_Id,
            Room_Id = r.Room_Id,
            CheckInDate = r.CheckInDate,
            CheckOutDate = r.CheckOutDate,
            No_Guest = r.No_Guest,
            Status = r.Status,
        })
        .FirstOrDefaultAsync();

    if (reservation == null)
    {
        return NotFound();
    }

    return Ok(reservation);
}


//-----------------1.test for frontend(bills dropdown) end------------------




        // POST: api/Reservations
        [HttpPost("Create")]
        public async Task<ActionResult<ReservationDTO>> CreateReservation(ReservationDTO reservationDTO)
        {
            if (reservationDTO == null)
            {
                return BadRequest("Reservation data is null.");
            }
            if (reservationDTO.CheckInDate < DateTime.Today)
            {
                return BadRequest("Check-in date cannot be earlier than today.");
            }

            if (reservationDTO.CheckOutDate <= reservationDTO.CheckInDate)
            {
                return BadRequest("Check-out date must be later than the check-in date.");
            }


            //test for booking---------------------------

            // Check if the room is available
        var room = await _context.Rooms.FindAsync(reservationDTO.Room_Id);
        if (room == null)
        {
            return NotFound("Room not found.");
        }

        if (room.Status != "Available")
        {
            return Conflict("Room is not available.");
        }

            //test end-------------------------------------


            var reservation = new Reservation
            {
                Guest_Id = reservationDTO.Guest_Id,
                Room_Id = reservationDTO.Room_Id,
                CheckInDate = reservationDTO.CheckInDate,
                CheckOutDate = reservationDTO.CheckOutDate,
                No_Guest = reservationDTO.No_Guest,
                //testing for reservation status (pending-Booked)
                Status = reservationDTO.Status,
                // Status="Pending"



                // Price = reservationDTO.Price,
                // Tax = reservationDTO.Tax,
                // TotalAmount = reservationDTO.TotalAmount
            };

            _context.Reservations.Add(reservation);

            //room status changes to booked after reservation----------------------------
            room.Status = "Booked"; // Change the status to Booked

            //reservation status change
            // reservation.Status = "Booked"; // Update reservation status

            //reservation status change ends
            _context.Entry(room).State = EntityState.Modified;
            //status end--------------------------
            await _context.SaveChangesAsync();

            reservationDTO.Reservation_Id = reservation.Reservation_Id; // Update DTO with the generated ID

            return CreatedAtAction(nameof(GetReservation), new { id = reservation.Reservation_Id }, reservationDTO);
        }

        // PUT: api/Reservations/5
        [HttpPut("Update/{id}")]
        public async Task<IActionResult> UpdateReservation(int id, ReservationDTO reservationDTO)
        {
            if (id != reservationDTO.Reservation_Id)
            {
                return BadRequest("ID mismatch.");
            }

            var reservation = await _context.Reservations.FindAsync(id);
            if (reservation == null)
            {
                return NotFound();
            }

            reservation.Guest_Id = reservationDTO.Guest_Id;
            reservation.Room_Id = reservationDTO.Room_Id;
            reservation.CheckInDate = reservationDTO.CheckInDate;
            reservation.CheckOutDate = reservationDTO.CheckOutDate;
            reservation.No_Guest = reservationDTO.No_Guest;
            reservation.Status = reservationDTO.Status;
            // reservation.Price = reservationDTO.Price;
            // reservation.Tax = reservationDTO.Tax;
            // reservation.TotalAmount = reservationDTO.TotalAmount;

            _context.Entry(reservation).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE: api/Reservations/5
        [HttpDelete("Delete/{id}")]
        public async Task<IActionResult> DeleteReservation(int id)
        {
            var reservation = await _context.Reservations.FindAsync(id);
            if (reservation == null)
            {
                return NotFound("Reservation not found");
            }

            //newly added
            var room = await _context.Rooms.FindAsync(reservation.Room_Id);
            if (room == null)
            {
                return NotFound("Room not found.");
            }
            //newly added end

            _context.Reservations.Remove(reservation);

            //2newly added(for room status changes back to available when reservation is deleted)
             room.Status = "Available";
            _context.Entry(room).State = EntityState.Modified;
            //2 end


            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
