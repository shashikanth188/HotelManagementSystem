using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HotelManagementSystem.Models;
using Microsoft.AspNetCore.Authorization;
using Sending_Emails_in_Asp.Net_Core;


[Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Owner")]
    public class AdminController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IPasswordHasher<Admin> _passwordHasher;
        //email
        private readonly EmailSending _email;

        //logintest
        private readonly IConfiguration _configuration;

    public AdminController(AppDbContext context,  EmailSending email, IConfiguration configuration, IPasswordHasher<Admin> passwordHasher)
        {
            _context = context;
           _passwordHasher = passwordHasher;
            _email = email;
            _configuration=configuration;
        }

        // GET: api/admin
        [HttpGet("All_Details")]

        public async Task<ActionResult<IEnumerable<Admin>>> GetAllAdmins()
        {
            return await _context.Admins.ToListAsync();
        }

        // GET: api/admin/5
        [HttpGet("Find")]
        public async Task<ActionResult<Admin>> GetAdminById(int id)
        {
            var admin = await _context.Admins.FindAsync(id);

            if (admin == null)
            {
                return NotFound(new { Message = $"No details found with id {id}" });
            }
            
            return admin;
        }

        // POST: api/admin
        [HttpPost("Create")]
        
        public async Task<ActionResult<Admin>> CreateAdmin(Admin admin)
    {
        
        if (admin == null)
        {
            return BadRequest("Admin cannot be null");
        }
        //convert to lower
        admin.UserName = admin.UserName?.ToLower();
        admin.EmailId = admin.EmailId?.ToLower();
        //username exists
        if (await _context.Admins.AnyAsync(u => u.UserName == admin.UserName))
            {
                return Conflict(new { Message = "Username already exists. Try using different name" });
            }

        //email exists
        if (await _context.Admins.AnyAsync(u => u.EmailId == admin.EmailId))
            {
                return Conflict(new { Message = "Email already exists. Try using different email" });
            }



        // Hash the password before storing
        admin.Password = _passwordHasher.HashPassword(admin, admin.Password);

        _context.Admins.Add(admin);
        await _context.SaveChangesAsync();
        //email
       // _email.SendEmail(admin.EmailId,admin.UserName);
        //email end

        return CreatedAtAction(nameof(GetAdminById), new { id = admin.User_Id }, admin);
    }

        // PUT: api/admin/5
        [HttpPut("Update")]
        public async Task<IActionResult> UpdateAdmin(int id, Admin admin)
        {
            if (id != admin.User_Id)
            {
                return BadRequest();
            }

            _context.Entry(admin).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Admins.Any(e => e.User_Id == id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // DELETE: api/admin/5
        [HttpDelete("Delete")]
        public async Task<IActionResult> DeleteAdmin(int id)
        {
            var admin = await _context.Admins.FindAsync(id);
            if (admin == null)
            {
                return NotFound();
            }

            _context.Admins.Remove(admin);
            await _context.SaveChangesAsync();

            return NoContent();
        }


}
//------------------------------------------------------------------------

//         //---revenue----
[ApiController]
[Route("api/[controller]")]
[Authorize(Roles = "Owner")]
public class ReportController : ControllerBase
{
    private readonly ReportService _revenueService;

    public ReportController(ReportService revenueService)
    {
        _revenueService = revenueService;
    }

    [HttpGet("monthly/{id}")]
    public async Task<IActionResult> GetMonthlyRevenue([FromQuery] DateTime date)
    {
        var revenue = await _revenueService.GetMonthlyRevenueAsync(date);
        return Ok(new { Month = date.ToString("MMMM yyyy"), Revenue = revenue });
    }


    [HttpGet("yearly/{id}")]
    public async Task<IActionResult> GetYearlyRevenue([FromQuery] int year)
    {
        // Get the current year
    int currentYear = DateTime.Now.Year;

    // Validate the year parameter
    if (year > currentYear)
    {
        // Return a BadRequest with a meaningful error message
        return BadRequest(new { Error = $"Year cannot be greater than the current year {currentYear}." });
    }

        var revenue = await _revenueService.GetYearlyRevenueAsync(year);
        return Ok(new { Year = year, Revenue = revenue });
    }

    [HttpGet("range")]
    public async Task<IActionResult> GetRevenueByRange([FromQuery] DateTime fromDate, [FromQuery] DateTime toDate)
    {
        if (fromDate > toDate)
        {
            return BadRequest(new { Message = "The 'fromDate' cannot be later than 'toDate'." });
        }

        var revenue = await _revenueService.GetRevenueByRangeAsync(fromDate, toDate);
        return Ok(new { FromDate = fromDate.ToString("yyyy-MM-dd"), ToDate = toDate.ToString("yyyy-MM-dd"), Revenue = revenue });
    }
}