
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HotelManagementSystem.Models;
using Microsoft.AspNetCore.Authorization; 

namespace HotelManagementSystem.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Owner,Manager,Receptionist")]
    public class RoomsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public RoomsController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/Rooms
        [HttpGet("All_Rooms")]
        public async Task<ActionResult<IEnumerable<RoomDTO>>> GetRooms()
        {
            var rooms = await _context.Rooms
                .Select(r => new RoomDTO
                {
                    Room_Id = r.Room_Id,
                    RoomNumber = r.RoomNumber,
                    RoomType = r.RoomType,
                    //Description = r.Description,
                    Status = r.Status,
                    //TotalAmount = r.TotalAmount
                })
                .ToListAsync();

            return Ok(rooms);
        }

        //available rooms
        [HttpGet("Available")]
public async Task<ActionResult<IEnumerable<RoomDTO>>> GetAvailableRooms()
{
    var availableRooms = await _context.Rooms
        .Where(r => r.Status == "Available") // Assuming "Available" is the status for free rooms
        .Select(r => new RoomDTO
        {
            Room_Id = r.Room_Id,
            RoomNumber = r.RoomNumber,
            RoomType = r.RoomType,
            Status = r.Status,
        })
        .ToListAsync();

    return Ok(availableRooms);
}

//occupied rooms
[HttpGet("Occupied")]
public async Task<ActionResult<IEnumerable<RoomDTO>>> GetBookedRooms()
{
    var bookedRooms = await _context.Rooms
        .Where(r => r.Status == "Booked") // Assuming "Booked" is the status for occupied rooms
        .Select(r => new RoomDTO
        {
            Room_Id = r.Room_Id,
            RoomNumber = r.RoomNumber,
            RoomType = r.RoomType,
            Status = r.Status,
        })
        .ToListAsync();

    return Ok(bookedRooms);
}

[HttpGet("FindRoom")]
public async Task<ActionResult<RoomDTO>> GetRoom( int roomNumber)
{
    if (roomNumber <= 0) // Assuming room numbers are positive integers
    {
        return BadRequest("Invalid Room Number.");
    }

    var room = await _context.Rooms
        .Where(r => r.RoomNumber == roomNumber)
        .Select(r => new RoomDTO
        {
            Room_Id = r.Room_Id,
            RoomNumber = r.RoomNumber,
            RoomType = r.RoomType,
            Status = r.Status
        })
        .FirstOrDefaultAsync();

    if (room == null)
    {
        return NotFound();
    }

    return Ok(room);
}




        // POST: api/Rooms
        [HttpPost("Create")]
        public async Task<ActionResult<RoomDTO>> CreateRoom(RoomDTO roomDTO)
        {
            if (roomDTO == null)
            {
                return BadRequest("Room data is null.");
            }

            var room = new Room
            {
                RoomNumber = roomDTO.RoomNumber,
                RoomType = roomDTO.RoomType,
                //Description = roomDTO.Description,
                Status = roomDTO.Status,
                //TotalAmount = roomDTO.TotalAmount
            };

            _context.Rooms.Add(room);
            await _context.SaveChangesAsync();

            roomDTO.Room_Id = room.Room_Id; // Update the DTO with the generated ID

            return CreatedAtAction(nameof(GetRoom), new { id = room.Room_Id }, roomDTO);
        }

        // PUT: api/Rooms/5
        [HttpPut("Update/{id}")]
        public async Task<IActionResult> UpdateRoom(int id, RoomDTO roomDTO)
        {
            if (id != roomDTO.Room_Id)
            {
                return BadRequest("ID mismatch.");
            }

            var room = await _context.Rooms.FindAsync(id);
            if (room == null)
            {
                return NotFound();
            }

            room.RoomNumber = roomDTO.RoomNumber;
            room.RoomType = roomDTO.RoomType;
            //room.Description = roomDTO.Description;
            room.Status = roomDTO.Status;
            //room.TotalAmount = roomDTO.TotalAmount;

            _context.Entry(room).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE: api/Rooms/5
        [HttpDelete("Delete/{id}")]
        public async Task<IActionResult> DeleteRoom(int id)
        {
            var room = await _context.Rooms.FindAsync(id);
            if (room == null)
            {
                return NotFound();
            }

            _context.Rooms.Remove(room);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}

