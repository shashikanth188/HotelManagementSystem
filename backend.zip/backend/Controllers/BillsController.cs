using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HotelManagementSystem.Models;
using Microsoft.AspNetCore.Authorization;

[ApiController]
[Route("api/[controller]")]
[Authorize(Roles = "Owner,Receptionist")]
public class BillController : ControllerBase
{
    private readonly AppDbContext _context;

    public BillController(AppDbContext context)
    {
        _context = context;
    }

    // GET: api/Bill
    [HttpGet("All_Details")]
    public async Task<ActionResult<IEnumerable<BillDTO>>> GetBills()
    {
        return await _context.Bills
            .Select(bill => new BillDTO
            {
                Bill_Id = bill.Bill_Id,
                Reservation_Id = bill.Reservation_Id,
                Price = bill.Price,
                Tax = bill.Tax,
                TotalAmount = bill.TotalAmount
            })
            .ToListAsync();
    }

    // GET: api/Bill/5
    // [HttpGet("FindById")]
    // public async Task<ActionResult<BillDTO>> GetBill(int id)
    // {
    //     var bill = await _context.Bills
    //         .Select(bill => new BillDTO
    //         {
    //             Bill_Id = bill.Bill_Id,
    //             Reservation_Id = bill.Reservation_Id,
    //             Price = bill.Price,
    //             Tax = bill.Tax,
    //             TotalAmount = bill.TotalAmount
    //         })
    //         .SingleOrDefaultAsync(b => b.Bill_Id == id);

    //     if (bill == null)
    //     {
    //         return NotFound();
    //     }

    //     return bill;
    // }

    //find by email
    [HttpGet("FindByGuestEmail")]
public async Task<ActionResult<BillDTO>> GetBill(string email)
{
    var bill = await _context.Bills
        .Join(
            _context.Reservations,
            bill => bill.Reservation_Id,
            reservation => reservation.Reservation_Id,
            (bill, reservation) => new { bill, reservation.Guest_Id }
        )
        .Join(
            _context.Guests,
            br => br.Guest_Id,
            guest => guest.Guest_Id,
            (br, guest) => new { br.bill, guest.Email }
        )
        .Where(bg => bg.Email == email)
        .Select(bg => new BillDTO
        {
            Bill_Id = bg.bill.Bill_Id,
            Reservation_Id = bg.bill.Reservation_Id,
            Price = bg.bill.Price,
            Tax = bg.bill.Tax,
            TotalAmount = bg.bill.TotalAmount
        })
        .SingleOrDefaultAsync();

    if (bill == null)
    {
        return NotFound();
    }

    return bill;
}

    //find by email ends


    //================== test for reservation updation ================(WORKING)

[HttpPost("Create")]
public async Task<ActionResult<BillDTO>> PostBill([FromBody] BillDTO billDto)
{
    // Validate Price and Tax (optional)
    // if (billDto.Price <= 0 || billDto.Tax <= 0)
    // {
    //     return BadRequest("Price and Tax cannot be negative values.");
    // }

    // Calculate TotalAmount
    var bill = new Bill
    {
        Reservation_Id = billDto.Reservation_Id,
        Price = billDto.Price,
        Tax = billDto.Tax,
        TotalAmount = billDto.Price + billDto.Tax
    };

    // Add the bill to the database
    _context.Bills.Add(bill);
    await _context.SaveChangesAsync();

    // Update the DTO with the generated Bill_Id
    billDto.Bill_Id = bill.Bill_Id;

    // Retrieve the reservation and update its status to "Booked"
    var reservation = await _context.Reservations.FindAsync(billDto.Reservation_Id);
    if (reservation != null)
    {
        reservation.Status = "Booked"; // Change the status to "Booked"
        _context.Entry(reservation).State = EntityState.Modified;
        await _context.SaveChangesAsync();
    }
    else
    {
        return NotFound("Reservation not found.");
    }

    return CreatedAtAction(nameof(GetBill), new { id = billDto.Bill_Id }, billDto);
}


    //==================test for reservation updation ends================


    
    // PUT: api/Bill/5
    [HttpPut("Update")]
    public async Task<IActionResult> PutBill(int id, BillDTO billDto)
    {
        if (id != billDto.Bill_Id)
        {
            return BadRequest();
        }

        //negative price validation
        if (billDto.Price < 0 || billDto.Tax < 0)
        {
            return BadRequest("values cannot be negative.");
        }
        if(billDto.TotalAmount < 0)
        {
             return BadRequest("values cannot be negative.");
        }

        var bill = await _context.Bills.FindAsync(id);

        if (bill == null)
        {
            return NotFound();
        }

        // Update the bill entity
        bill.Reservation_Id = billDto.Reservation_Id;
        bill.Price = billDto.Price;
        bill.Tax = billDto.Tax;
        bill.TotalAmount = billDto.Price + billDto.Tax; // Recalculate TotalAmount

        _context.Entry(bill).State = EntityState.Modified;

        try
        {
            await _context.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!BillExists(id))
            {
                return NotFound();
            }
            else
            {
                throw;
            }
        }

        return NoContent();
    }

    // DELETE: api/Bill/5
    [HttpDelete("Delete")]
    public async Task<IActionResult> DeleteBill(int id)
    {
        var bill = await _context.Bills.FindAsync(id);
        if (bill == null)
        {
            return NotFound();
        }

        _context.Bills.Remove(bill);
        await _context.SaveChangesAsync();

        return NoContent();
    }
    private bool BillExists(int id)
    {
        return _context.Bills.Any(e => e.Bill_Id == id);
    }
}