using HotelManagementSystem.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HotelManagementSystem.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Owner,Manager")]
    public class InventoriesController : ControllerBase
    {
        private readonly AppDbContext _context;

        public InventoriesController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/Inventories
        [HttpGet]
        public async Task<IActionResult> GetInventories()
        {
            var inventories = await _context.Inventories.ToListAsync();
            return Ok(inventories); // Returns a JSON representation of the list of inventories
        }

        // GET: api/Inventories/5
        [HttpGet("FindById")]
        public async Task<IActionResult> GetInventory(int id)
        {
            var inventory = await _context.Inventories.FindAsync(id);

            if (inventory == null)
            {
                return NotFound(); // Returns a 404 if the inventory is not found
            }

            return Ok(inventory); // Returns a JSON representation of the inventory
        }

        // POST: api/Inventories
        [HttpPost("Create/{id}")]
        public async Task<IActionResult> CreateInventory([FromBody] Inventory inventory)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // Returns a 400 if the model state is invalid
            }
            if (inventory.Quantity <=0 || inventory.Unit_Price<=0 )
            {
            return BadRequest(" cannot be zero or negative.");
            }
           

            _context.Inventories.Add(inventory);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetInventory), new { id = inventory.Inventory_Id }, inventory);
        }

        // PUT: api/Inventories/5
        [HttpPut("Update/{id}")]
        public async Task<IActionResult> UpdateInventory(int id, [FromBody] Inventory inventory)
        {
            if (id != inventory.Inventory_Id)
            {
                return BadRequest(); // Returns a 400 if IDs do not match
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // Returns a 400 if the model state is invalid
            }

            try
            {
                _context.Entry(inventory).State = EntityState.Modified;
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!InventoryExists(id))
                {
                    return NotFound(); // Returns a 404 if the inventory does not exist
                }
                else
                {
                    throw; // Re-throw the exception if it’s not a missing entity
                }
            }

            return NoContent(); // Returns a 204 No Content on successful update
        }

        // DELETE: api/Inventories/5
        [HttpDelete("Delete/{id}")]
        public async Task<IActionResult> DeleteInventory(int id)
        {
            var inventory = await _context.Inventories.FindAsync(id);

            if (inventory == null)
            {
                return NotFound(); // Returns a 404 if the inventory is not found
            }

            _context.Inventories.Remove(inventory);
            await _context.SaveChangesAsync();

            return NoContent(); // Returns a 204 No Content on successful deletion
        }

        private bool InventoryExists(int id)
        {
            return _context.Inventories.Any(e => e.Inventory_Id == id);
        }
    }
}
