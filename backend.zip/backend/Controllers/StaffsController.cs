using HotelManagementSystem.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HotelManagementSystem.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Owner,Manager")]
    
    public class StaffController : ControllerBase
    {
        private readonly AppDbContext _context;

        public StaffController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/Staff
        [HttpGet]
        public async Task<IActionResult> GetStaff()
        {
            var staff = await _context.Staff.ToListAsync();
            return Ok(staff); // Returns a JSON representation of the list of staff members
        }

    
        [HttpGet("Find")]
        public async Task<IActionResult> GetStaff(int id)
        {
            var staff = await _context.Staff.FirstOrDefaultAsync(m => m.Staff_ID == id);

            if (staff == null)
            {
                return NotFound(); // Returns a 404 if the staff member is not found
            }

            return Ok(staff); // Returns a JSON representation of the staff member
        }

        // POST: api/Staff
        [HttpPost("Create")]
        public async Task<IActionResult> CreateStaff([FromBody] Staff staff)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // Returns a 400 if the model state is invalid
            }
            // if (await _context.Staff.AnyAsync(u => u.Staff_Name == staff.Staff_Name))
            // {
            //     return Conflict(new { Message = "Username already exists. Try using different name" });
            // }

            _context.Staff.Add(staff);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetStaff), new { id = staff.Staff_ID }, staff);
        }

        // PUT: api/Staff/5
        [HttpPut("Update/{id}")]
        public async Task<IActionResult> UpdateStaff(int id, [FromBody] Staff staff)
        {
            if (id != staff.Staff_ID)
            {
                return BadRequest(); // Returns a 400 if IDs do not match
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // Returns a 400 if the model state is invalid
            }

            try
            {
                _context.Entry(staff).State = EntityState.Modified;
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!StaffExists(id))
                {
                    return NotFound(); // Returns a 404 if the staff member does not exist
                }
                else
                {
                    throw; // Re-throw the exception if it’s not a missing entity
                }
            }

            return NoContent(); // Returns a 204 No Content on successful update
        }

        // DELETE: api/Staff/5
        [HttpDelete("Delete/{id}")]
        public async Task<IActionResult> DeleteStaff(int id)
        {
            var staff = await _context.Staff.FindAsync(id);

            if (staff == null)
            {
                return NotFound(); // Returns a 404 if the staff member is not found
            }

            _context.Staff.Remove(staff);
            await _context.SaveChangesAsync();

            return NoContent(); // Returns a 204 No Content on successful deletion
        }

        private bool StaffExists(int id)
        {
            return _context.Staff.Any(e => e.Staff_ID == id);
        }
    }
}