using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HotelManagementSystem.Models;
using Microsoft.AspNetCore.Authorization;
using Sending_Emails_in_Asp.Net_Core;

namespace HotelManagementSystem.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Owner,Receptionist")]
    public class GuestsController : ControllerBase
    {
        private readonly AppDbContext _context;
        //email
        private readonly EmailSending _email;
        public GuestsController(AppDbContext context, EmailSending email)
        {
            _context = context;
            _email = email;
        }

        // GET: api/Guests
        [HttpGet("All_Details")]
        public async Task<ActionResult<IEnumerable<GuestDTO>>> GetGuests()
        {
            var guests = await _context.Guests
                .Select(g => new GuestDTO
                {
                    Guest_Id = g.Guest_Id,
                    Name = g.Name,
                    Email = g.Email,
                    Gender = g.Gender,
                    Address = g.Address,
                    PhoneNo = g.PhoneNo
                })
                .ToListAsync();

            return Ok(guests);
        }

        // GET: api/Guests/5
        // [HttpGet("FindbyID")]
        // public async Task<ActionResult<GuestDTO>> GetGuest(int id)
        // {
        //     var guest = await _context.Guests
        //         .Where(g => g.Guest_Id == id)
        //         .Select(g => new GuestDTO
        //         {
        //             Guest_Id = g.Guest_Id,
        //             Name = g.Name,
        //             Email = g.Email,
        //             Gender = g.Gender,
        //             Address = g.Address,
        //             PhoneNo = g.PhoneNo
        //         })
        //         .FirstOrDefaultAsync();

        //     if (guest == null)
        //     {
        //         return NotFound();
        //     }

        //     return Ok(guest);
        // }

        //search by email test
        [HttpGet("Find_Guest")]
        public async Task<ActionResult<GuestDTO>> GetGuest(string email)
        {
            // Validate the email parameter
            if (string.IsNullOrWhiteSpace(email))
            {
                return BadRequest("Email is required.");
            }
            // Convert email to lowercase for case-insensitive comparison
            email = email.Trim().ToLower();

            var guest = await _context.Guests
            .Where(g => g.Email.ToLower() == email)
            .Select(g => new GuestDTO
        {
            Guest_Id = g.Guest_Id,
            Name = g.Name,
            Email = g.Email,
            Gender = g.Gender,
            Address = g.Address,
            PhoneNo = g.PhoneNo
        })
        .FirstOrDefaultAsync();

            return Ok(guest);
        }
        //search by email test end


        // POST: api/Guests
        [HttpPost("Create")]
        public async Task<ActionResult<GuestDTO>> CreateGuest(GuestDTO guestDTO)
        {
            if (guestDTO == null)
            {
                return BadRequest("Guest data is null.");
            }
            //repeated email validation 
        var existingGuest = await _context.Guests
        .FirstOrDefaultAsync(g => g.Email == guestDTO.Email);

        if (existingGuest != null)
        {
            return Conflict("A guest with this email already exists.");
        }
        // repeated email validation end

            var guest = new Guest
            {
                Name = guestDTO.Name,
                Email = guestDTO.Email,
                Gender = guestDTO.Gender,
                Address = guestDTO.Address,
                PhoneNo = guestDTO.PhoneNo
            };

            _context.Guests.Add(guest);
            await _context.SaveChangesAsync();

            guestDTO.Guest_Id = guest.Guest_Id; 

            //email
        //    _email.SendEmail(guest.Email,guest.Name);

            return CreatedAtAction(nameof(GetGuest), new { id = guest.Guest_Id }, guestDTO);
        }

        // PUT: api/Guests/5
        [HttpPut("Update")]
        public async Task<IActionResult> UpdateGuest(int id, GuestDTO guestDTO)
        {
            if (id != guestDTO.Guest_Id)
            {
                return BadRequest("ID mismatch.");
            }

            var guest = await _context.Guests.FindAsync(id);
            if (guest == null)
            {
                return NotFound();
            }

            guest.Name = guestDTO.Name;
            guest.Email = guestDTO.Email;
            guest.Gender = guestDTO.Gender;
            guest.Address = guestDTO.Address;
            guest.PhoneNo = guestDTO.PhoneNo;

            _context.Entry(guest).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE: api/Guests/5
        [HttpDelete("Delete")]
        public async Task<IActionResult> DeleteGuest(int id)
        {
            var guest = await _context.Guests.FindAsync(id);
            if (guest == null)
            {
                return NotFound();
            }

            _context.Guests.Remove(guest);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
