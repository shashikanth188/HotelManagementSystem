using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using HotelManagementSystem.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly AppDbContext _context;
   private readonly IPasswordHasher<Admin> _passwordHasher;
    private readonly IConfiguration _configuration;
    public AuthController(AppDbContext context, IConfiguration configuration, IPasswordHasher<Admin> passwordHasher)
    {
        _context = context;
       _passwordHasher = passwordHasher;
        _configuration = configuration;
    }


[HttpPost("Login")]
public async Task<ActionResult<string>> PostLogin([FromBody] LoginModel loginDto)
{
    if (loginDto == null)
    {
        return BadRequest("User data is null");
    }

    // Fetch the user based on email
    var user = await _context.Admins
        .FirstOrDefaultAsync(u => u.EmailId == loginDto.Email);

    if (user != null)
    {
       
        if (user == null || !_passwordHasher.VerifyHashedPassword(user, user.Password, loginDto.Password).Equals(PasswordVerificationResult.Success))
//             return Unauthorized();
        {
            // Ensure no null values are passed to the Claim constructor
            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, _configuration["Jwt:Subject"] ?? "DefaultSubject"),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim("AdminName", user.UserName ?? "DefaultUserName"),
                new Claim("AdminEmail", user.EmailId ?? "DefaultEmail"),
                new Claim(ClaimTypes.Role, user.Role ?? "DefaultRole")
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
            var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var token = new JwtSecurityToken(
                _configuration["Jwt:Issuer"],
                _configuration["Jwt:Audience"],
                claims,
                expires: DateTime.UtcNow.AddMinutes(60),
                signingCredentials: signIn
            );

            string tokenValue = new JwtSecurityTokenHandler().WriteToken(token);
            return Ok(new { Token = tokenValue, Admin = user });
        }
        else
        {
            return Unauthorized("Invalid password");
        }
    }
    else
    {
        return Unauthorized("Invalid email");
    }
}
}
