using System.ComponentModel.DataAnnotations;

public class RoomDTO
{
    public int Room_Id{get; set;}
    [Required]    
    public int RoomNumber{get; set;}
    [Required]
    public string RoomType{get; set;}
    
   // public string Description{get; set;}
    [Required]
    public string Status{get; set;}
    
    //public decimal TotalAmount{get; set;}
}