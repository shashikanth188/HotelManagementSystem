using System.ComponentModel.DataAnnotations;
public class BillDTO
{
    public int Bill_Id{get; set;}
    public int Reservation_Id{get; set;}
    [Required]
    public double Price{get; set;}
    [Required]
    public double Tax{get; set;}
    
    public double TotalAmount{get; set;}
}