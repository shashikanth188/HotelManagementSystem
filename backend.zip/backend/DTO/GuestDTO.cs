using System.ComponentModel.DataAnnotations;
   public class GuestDTO
   {
    public int Guest_Id{get; set;}
    [Required]
    public string Name{get; set;}
    [Required]
    [DataType(DataType.EmailAddress)]
    public string Email{get; set;}
    [Required]
    public string Gender{get; set;}
    [Required]
    public string Address{get; set;}
    [Required]
    public string PhoneNo{get; set;}
   }