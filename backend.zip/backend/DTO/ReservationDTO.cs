using System.ComponentModel.DataAnnotations;
public class ReservationDTO
{
    
    public int Reservation_Id{get; set;}
    public int Guest_Id{get; set;}
    public int Room_Id{get; set;}
    [Required]
    [DataType(DataType.Date)]
    //[FutureDate(ErrorMessage = "Check-in date must be in the future.")]
    public DateTime CheckInDate{get; set;}
    [Required]
    [DataType(DataType.Date)]
    //[FutureDate(ErrorMessage = "Check-out date must be in the future.")]
    //[CheckOutDateGreaterThanCheckInDate(ErrorMessage = "Check-out date must be later than check-in date.")]
    public DateTime CheckOutDate{get; set;}
    [Required]
    public int No_Guest{get; set;}
    [Required]
    public string Status{get; set;}

}